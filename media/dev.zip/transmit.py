
from connect import orugaConnect

if __name__ == "__main__":
    conn = orugaConnect()
    conn.main()
            
