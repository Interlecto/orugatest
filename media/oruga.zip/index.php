<?php
# Interlecto Content Management System
# ICMS Version 0.5
ob_start();

# Get general cms options
require_once "lib/cms.php";

# Get site configuration options
require_once "site_config.php";

# Get session and request status
require_once "lib/params.php";

# Get the page
ob_start();
require_once "lib/go.php";
$page = ob_get_clean();
if(il_empty('user') && il_get('cachable'))
	il_cache_set(il_get('line'),$page);

# Send everything
$debug = ob_get_clean();
echo $page;
if($debug)
	echo "\n<!-- ## DEBUG INFORMATION ##\n$debug\n-->\n";
?>