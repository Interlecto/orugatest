<?php
if(!($user=il_get('user'))) {
	redirect('inicio.html');
}
il_put('title',"Oruga Amarilla: La comunidad de la maquinaria");

function sectionlist($link,$content,$text=null,$level='h2',$id="") {
	global $dir;
	if(!$text) {
		$text = ucfirst($link);
		$link = seo($link);
	}
	$x = (strrpos($link,'/') || strrpos($link,'.'))? "": "/";
	if(!$id) {
		$id=$x?$link:str_replace(array('-','/',' '),'-',$link);
	}
	return "<section class=portallist id=$id><$level><a href=\"$dir/$link$x\">$text</a></$level>\n$content\n</section>\n";
}

ob_start();
?>
<section id=portal>
<?php
if(module_exists('catalog')) {
	echo sectionlist('venta',product_list(4,'venta',false,null),'Compra y venta de maquinaria');
	echo sectionlist('alquiler',product_list(4,'alquiler',false,null),'Alquiler de maquinaria');
	echo sectionlist('repuestos',product_list(4,'repuestos',false,null),'Compra y venta de repuestos');
}
?>
<section id=dns><a href=/dns.html>DNS</a></section>
<hr class=clear>
</section>
<?php
return ob_get_clean()
	#."\n<pre>".print_r($GLOBALS['il'],true)."</pre>\n";
?>