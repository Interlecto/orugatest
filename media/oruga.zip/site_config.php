<?php
# Interlecto Content Management System
# ICMS Version 0.5
# site_config.php | site configuration options

il_put('sitename','Oruga Amarilla');
il_put('type','page');
#il_put('cachable',true);

set_area('title');
set_area('footer');
set_area('usernav');
set_area('sitetitle');
set_area('notes');
set_area('twitter');

?>