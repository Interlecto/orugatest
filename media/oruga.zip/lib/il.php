<?php

define("IL_IGNORE", 1);

class Attributer {
	private $vars=array();

	public function __construct() {
	}

	#functions to check existence of keys
	public function exist($key) {
		return isset($this->vars[$key]);
	}
	public function empt($key) {
		return empty($this->vars[$key]);
	}
	public function is_array($key) {
		return isset($this->vars[$key]) && is_array($this->vars[$key]);
	}

	#functions to set and retrieve values of single keys
	public function get($key, $default=null) {
		return isset($this->vars[$key])? $this->vars[$key]: $default;
	}
	public function set($key, $value) {
		$this->vars[$key] = $value;
	}
	public function put($key, $value) {
		if(empty($this->vars[$key])) $this->vars[$key] = $value;
	}
	public function add($key, $value) {
		if(isset($this->vars[$key])) {
			if(is_array($this->vars[$key]))
				array_push($this->vars[$key],$value);
			elseif(is_string($this->vars[$key]))
				$this->vars[$key].= $value;
			elseif(is_numeric($this->vars[$key]))
				$this->vars[$key]+= $value;
		}
	}
	
	#functions to create new attributes
	public function newvar($key,$value=null)
									{ $this->set($key,$value); }
	public function newstr($key)	{ $this->set($key,''); }
	public function newnum($key)	{ $this->set($key,0); }
	public function newarr($key)	{ $this->set($key,array()); }
	
	#destroy attribute
	public function clear($key)	{ unset($this->vars[$key]); }
}

class Site extends Attributer {
	private $arrs=array();
	
	public $modules=array();
	public $areas=array();
	public $paths=array();
	
	public function __construct() {
		$template = 'nuevo';
		$this->newvar('template',$template);
		$this->newarr('path', array (
			'root' => "",
			'template' => "/template/$template",
			'js' => "/js",
			));
		$this->newvar('scripts',"\n");
	}
	
	#GENERAL KEYS
	
	#functions to check existence of keys
	public function is_array($key) {
		return isset($this->arrs[$key]) || (isset($this->vars[$key]) && is_array($this->vars[$key]));
	}
	public function existt($key,$sub) {
		return isset($this->arrs[$key]) && $this->arrs[$key]->exist($sub);
	}
	public function emptt($key,$sub) {
		return empty($this->arrs[$key]) || $this->arrs[$key]->empt($sub);
	}
	
	#destroy attribute or array
	public function clearr($key,$sub=null) {
		if($sub) {
			$this->arrs[$key]->clear($sub);
		} else {
			unset($this->arrs[$key]);
		}
	}

	#functions to create new attributes
	public function newarr($key, $value=array()) {
		$this->arrs[$key] = new Attributer;
		foreach($value as $k=>$v)
			$this->arrs[$key]->put($k,$v);
	}
	public function setkey($key, $value) {
		if(is_array($value))
			$this->newarr($key,$value);
		else
			$this->set($key,$value);
	}

	#functions to retrieve values of double keys 
	public function gett($key, $sub, $default=null) {
		return isset($this->arrs[$key]) && $this->arrs[$key]->exist($sub) ? $this->arrs[$key]->get($sub): $default;
	}
	public function sett($key, $sub, $value) {
		if(!isset($this->arrs[$key]))
			$this->arrs[$key] = new Attributer;
		$this->arrs[$key]->set($sub,$value);
	}
	public function putt($key, $sub, $value) {
		if(!isset($this->arrs[$key]))
			$this->arrs[$key] = new Attributer;
		$this->arrs[$key]->put($sub,$value);
	}
	
	# SPECIFIC KEYS
	public function set_path($path,$func,$alias=null) {
		$this->paths[$path] = $alias? array($func,$alias): $func;
	}

	public function fix_paths() {
		foreach($this->paths as $path=>$what) {
			if(is_array($what) && $what[0]=='alias')
				$this->paths[$path] = is_array($x=$this->paths[$what[1]])? $x[0]: $x;
		}
		foreach($this->paths as $path=>$what) {
			if(is_array($what) && $what[1]=='hiden')
				unset($this->paths[$path]);
		}
		ksort($this->paths);
	}
};

$il = new Site;

# ALIASING FUNCIONS
function il_empty($key) { return $GLOBALS['il']->empt($key); }
function il_set($key) { return $GLOBALS['il']->exist($key); }
function il_get($key,$def=null) { return $GLOBALS['il']->get($key,$def); }
function il_put($key,$val) { $GLOBALS['il']->set($key,$val); }
function il_default($key,$val) { $GLOBALS['il']->put($key,$val); }

function il_set2($key,$sub) { return $GLOBALS['il']->existt($key,$sub); }
function il_get2($key,$sub,$def=null) { return $GLOBALS['il']->gett($key,$sub,$def); }
function il_put2($key,$sub,$val) { $GLOBALS['il']->sett($key,$sub,$val); }

function set_paths($path,$func,$alias=null) { $GLOBALS['il']->set_path($path,$func,$alias); }
function fix_paths() { $GLOBALS['il']->fix_paths(); }

function module_exists($mod) { return in_array($mod,$GLOBALS['il']->modules); }

/*
*/
?>