<?php
# Interlecto Content Management System
# ICMS Version 0.5
# go.php | make and send requested page

# MAKE CONTENT

$line = il_get('line');
if(!($content=il_cache_content_get($line))) {
	$content_function = il_get('content_function','make_content');
	$content = function_exists($content_function)?
			$content_function($line):
				"<p>Function <strong>$content_function(<em>\$line</em>)</strong> does not exists.</p>\n".
				"<pre>".print_r($GLOBALS,true)."</pre>\n";
	if(il_get('cachable'))
		il_cache_content_set($line,$content);
}
il_default('title', mb_convert_case($line,MB_CASE_TITLE,'UTF-8'));
il_default('pagetitle', il_get('title'));

# MAKE PAGE
require_once "lib/braces.php";

$temppath = trim(il_get2('path','template','template/default'),'/');
$tempfile = il_get('templatefile','index.html');
echo unbrace(file_get_contents("$temppath/$tempfile"));

?>