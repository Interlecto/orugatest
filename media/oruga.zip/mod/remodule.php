<?php

class module {
	static $list = array();
	static $matches = array();
	static $names = array();
	static $data = array();
	static $order = array();
	
	private $name;
	private $instructions = array();
	private $cases = array();
	private $uses = array();
	
	public function __construct($module,$constructor=null) {
		module::$list[$module] = $this;
		$this->name = $module;
		$this->instructions = array(
			array(
				"// MODULE $module",
				"new module('$module');"),
			array(),
			array(),
			array(),
			array(),
			);
		if(is_string($constructor)) $this->process_file($constructor);
		if(is_array($constructor)) $this->process_array($constructor);
	}
	
	public function process_file($filename) {
		return $this->process_array(file($filename));
	}

	public function process_array($lines) {
		foreach($lines as $line) {
			preg_match('{\s*([^!#\r\n]*)([!#])?(.*)}',$line,$m).' ';
			if($m[2]=='!') continue;
			if($m[2]=='#') {
				$this->set_remark($m[3]);
				continue;
			}
			if(empty($m[1])) continue;
			preg_match_all('{\S+}',$m[1],$p);
			$com = array_shift($p[0]);
			if(method_exists($this,$a="set_$com")) {
				$this->$a($p[0]);
			} else {
				$this->set_remark("Unknown command '$com ".implode(' ',$p[0])."'");
			}
		}
	}
	
	public function set_remark($args) {
		if(is_array($args))
			$this->instructions[4][] = "// ".implode(' ',$args);
		else
			$this->instructions[4][] = "// ".trim($args);
	}

	public function set_data($args) {
		foreach($args as $dir) {
			$path = explode('/',$dir);
			if(empty($path[0]))
				array_shift($path);
			else
				array_unshift($path,'data');
			$ddir = ensure_path($path);
			$this->instructions[1][] = "// folder check '$ddir'";
			if(!isset(module::$data[$this->name])) module::$data[$this->name] = $ddir;
		}
	}

	public function set_file($args) {
		foreach($args as $dir) {
			$path = explode('/',$dir);
			if(empty($path[0]))
				array_shift($path);
			else
				array_unshift($path,'data');
			$fn = array_pop($path);
			$ddir = ensure_path($path);
			if(!file_exists($dfn="$ddir/$fn"))
				create_file($dfn);
			$this->instructions[1][] = "// file check '$dfn'";
		}
	}

	public function set_path($args) {
		$name = array_shift($args);
		$c = array();
		$n = false;
		foreach($args as $key) {
			if(preg_match('{([\w_]*)/?([\w_]*):([\w_]*)/?([\w_]*):?([\w_]*)}',$key,$m)) {
				break;
			}
			$c[]=$key;
		}
		if(empty($c)) {
			if(empty($m[4])) {
				$c[] = "^($name)(|/.*)$";
			} else {
				$c[] = "^($name)(|/|/.*/)$";
				$c[] = "^($name)(/.*[^/])$";
				$n = 1;
			}
		}

		$mod = empty($m[2])? $this->name: (empty($m[1])? $name: $m[1]);
		$file = "mod/$mod/".(empty($m[2])? (empty($m[1])? $name: $m[1]): $m[2]).".php";
		module::$names[$name] = array(
			'nominal'=>$c[0],
			'module'=>$this->name,
			'file'=>$file,
			'class'=>empty($m[3])? $name: $m[3],
		);
		if($m[5])
			module::$names[$name]['subdir'] = $m[5];
		if($n)
			module::set_case_item($name,$c[1],$m[4]);
		foreach($c as $k)
			module::set_match($k,$name);
	}
	
	public function set_section($args) {
		$name = array_shift($args);
		$c = array();
		foreach($args as $key)
			$c[] = $key;
		if(empty($c))
			$c[] = "^($name)(|/.*)$";
		module::$names[$name] = array(
			'nominal'=>$c[0],
			'module'=>$this->name,
			'file'=>'mod/static/display.php',
			'class'=>'static',
			'subdir'=>$name
		);
		foreach($c as $k)
			module::set_match($k,$name);
	}

	public function set_load($args) {
		foreach($args as $code) {
			if(substr($code,0,1)=='/')
				$code = substr($code,1).".php";
			else
				$code = "mod/{$this->name}/$code.php";
			$this->instructions[1][] = "require_once '$code';";
		}
	}

	public function set_require($args) {
		foreach($args as $mod)
			$this->uses[] = $mod;
	}

	public function set_redirect($args) {
	}

	public function set_alias($args) {
		$name = array_shift($args);
		$case = module::$names[$name];
		$c = array();
		foreach($args as $key) {
			$c[] = $key;
		}
		if(empty($c)) {
			return;
		}
	}

	public function set_ignore($args) {
		if(
	}
	
	public function print_instructions() {
		foreach($this->instructions as $block)
			if(count($block))
				echo implode("\n",$block)."\n";
		echo "\n";
	}
	
	static function set_match($match,$name) {
		module::$matches[$match] = $name;
	}

	static function set_case($name,$case,$class,$module,$file,$data=null) {
		module::$names[$name] = array(
			'nominal'=>$case,
			'module'=>$module,
			'file'=>$file,
			'class'=>$class,
		);
		if($data)
			module::$names[$name]['subdir'] = $data;
	}
	static function set_case_item($name,$case,$class) {
			module::$names[$name]['item_nominal'] = $case;
			module::$names[$name]['item_class'] = $class;
	}
	
	static function order($m) {
		if(in_array($m,module::$order)) return;
		foreach(module::$list[$m]->uses as $u)
			module::order($u);
		module::$order[] = $m;
	}

	static function fix() {
		foreach(array_keys(module::$list) as $m)
			module::order($m);
			
		foreach(module::$names as $n=>$a) {
			$mod = module::$list[$a['module']];
			$mod->instructions[2][] = isset($a['subdir'])?
				"module::\$set_case('$n','{$a['nominal']}','{$a['class']}','{$a['module']}','{$a['file']}','{$a['subdir']}');":
				"module::\$set_case('$n','{$a['nominal']}','{$a['class']}','{$a['module']}','{$a['file']}');";
			if(isset($a['item_nominal']))
				$mod->instructions[2][] = "module::\$set_case_item('$n','{$a['item_nominal']}','{$a['item_class']}');";
		}
		foreach(module::$matches as $m=>$n) {
			$case = module::$names[$n];
			$mod = module::$list[$case['module']];
			$mod->instructions[3][] = "module::\$set_match('$m','$n');";
		}
	}
};

function ensure_path($pp) { return implode('/',$pp); }
function create_file($dfn) { echo "Creating file '$dfn'\n"; }
?>