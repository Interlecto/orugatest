<?php

// URI cases:
//	/item/	redirects to feed.html for guests, and mine.html for users
//	/item/feed.html	show a dinamic list of all equipment the guest or user can get with respective access level
//	/item/mine.html	show a dinamic list of the equipment that belongs to the user.  Guests or users with no equipement attached are redirected to feed.html
//	/item/feed.json	All statuses for equipment a user or guest can browse
//	/item/mine.json	All statuses for equipment a user is attached to
//	/item/01234/	profile of an equipment, including dynamic feed
//	/item/01234/feed.html	dynamic view of latest statuses of equipment 01234
//	/item/01234/feed.json	json database of latest statuses of equipement 01234
//	/item/01234/
//	/item/01234/56789	view of a particular status
//	/item/as/user/feed.html	superuser view of "user" feed (applies only if superuser has precedence over user, even if superuser does not have direct access to a certain equipment)
//	/item/as/user/mine.html	superuser view of "user" mine feed (applies only if superuser has precedence over user, even if superuser does not have direct access to a certain equipment)

function make_item($line) {
	set_area('left');
	set_area('right');
	if($line=='index') {
		return item_feed();
	}
}

function item_feed($user=null,$item=null) {
	//	ver la base de datos de novedades de equipos
	//	filtrar por item
	//	por cada novedad (y su respectivo item)
	//		establecer qué nivel de vista tiene el usuario
	//		si el usuario puede ver la novedad:
	//			agregar novedad a la lista (con solo el nivel de vista)
	//	si la lista está vacía
	//		colocar un mensaje indicando que no hay novedades disponibles para ver
	//	ordenar la lista
	//	presentar los primeros n elementos.
	$d = listdir('data/datalog',-1,true);
	$ar = array();
	foreach($d as $b=>$a) {
		if(!isset($a[3])) continue;
		$ah = array('name'=>$b);
		if(file_exists($fn=$a[0].'/desc'))
			dat2array($fn,$ah);
		foreach($a[3] as $i=>$aa) {
			if(!isset($aa[3])) continue;
			$ai = array();
			if(file_exists($fn=$a[3]["$i.inst"][0]))
				dat2array($fn,$ai);
			foreach($aa[3] as $db=>$ab) {
				if(!isset($ab[3])) continue;
				$day = mktime(0,0,0,substr($db,4,2),substr($db,6),substr($db,0,4));
				break;
			}
			$ct = 3;
			foreach($ab[3] as $tb=>$ac) {
				if($ac[1]) continue;
				$time = mktime(substr($tb,0,2),substr($tb,2,2),substr($tb,4,2),substr($db,4,2),substr($db,6),substr($db,0,4));
				$aj = array();
				dat2array($ac[0],$aj);
				$ar[] = array($time,-$i,$ah,$ai,$aj);
				if(--$ct<=0) break;
			}
		}
	}
	rsort($ar);
	$r = "<div class=newsfeed>\n";
	foreach($ar as $v)
		$r.= item_write($v);
	$r.= "</div class=newsfeed>";
	return $r;
}

function item_write($ar) {
	ob_start();
	$or = array(
		'temperatura'=>array('temperatura','°C'),
		'tensao'=>array('intensidad lumínica',' lm'),
		'umidade'=>array('humedad',' %'),
	);
	$maq = sprintf('/item/%05d/',-$ar[1]);
	$ava = isset($ar[3]['avatar'])? $ar[3]['avatar']:(
		isset($ar[2]['avatar'])? $ar[3]['avatar']:
			'/images/def-avatar.png');
	$sta = sprintf('%s%05s',$maq,date('is',$ar[0]));
	$dat = date('j \d\e M, g:i:s a',$ar[0]);
	$mpars = array();
	$mpars[0] = (isset($ar[3]['descricao'])? $ar[3]['descricao']: 'Instrumento '.$ar[3]['id'])." (";
	$mpars[0].= (isset($ar[2]['descripcion'])? $ar[3]['descripcion']: 'Base '.$ar[2]['name']).")";
	foreach($ar[4] as $key=>$val) {
		foreach($or as $word=>$data) {
			if($key == $word)
				$mpars[] = sprintf("%s: %.1f%s", $data[0],$val/10,$data[1]);
			elseif(substr($key,0,strlen($word))==$word)
				$mpars[] = sprintf("%s %s: %.1f%s", $data[0],substr($key,strlen($word)),$val/10,$data[1]);
		}
	}
	$msg = implode(",<br>\n",$mpars).'.';
	if(isset($ar[4]['dataInicio'])) {
		$msg = 'Alarma en '.$msg;
		$msg.= ' '.$ar[4]['descricao'].'. ';
		$msg.= '<br>Inició: '.sdate2ascii($di=$ar[4]['dataInicio'],'D j \d\e M, g:i:s a.');
		if(isset($ar[4]['dataFim'])) {
			$df = $ar[4]['dataFim'];
			if(date('z',$df)==date('z',$di))
				$msg.= '<br>Finalizó: '.sdate2ascii($di=$ar[4]['dataFim'],' g:i:s a.');
			elseif(date('n',$df)==date('n',$di))
				$msg.= '<br>Finalizó: '.sdate2ascii($di=$ar[4]['dataFim'],'D j g:i:s a.');
			else
				$msg.= '<br>Finalizó: '.sdate2ascii($di=$ar[4]['dataFim'],'D j \d\e M g:i:s a.');
		}
	}
	#$msg.= "<span style='display:block;font-size:.6em;white-space:pre;float:left'>".print_r($ar[2],true)."</span>\n";
	#$msg.= "<span style='display:block;font-size:.6em;white-space:pre;float:left'>".print_r($ar[3],true)."</span>\n";
	#$msg.= "<span style='display:block;font-size:.6em;white-space:pre;float:left'>".print_r($ar[4],true)."</span>\n";
	#$msg.= "<hr style='clear:both'>\n";
?>
	<p class=item>
		<a class=avatar-link href="<?php echo $maq?>"><img class=avatar src="<?php echo $ava?>"></a>
		<a class=desc-link href='<?php echo $sta?>'>
		<span class=item-date><?php echo $dat?></span>
		<span class=item-desc><?php echo $msg?></span>
		</a>
	</p>
<?php
	return ob_get_clean();
}

/*
temperatura1] => 251
    [temperatura2] => 242
    [tensao] => 124
    [def] => 0
    [fan] => 1
    [comp] => 1
    [alrm] => 1
    [eco] => 0
    [digital1] => 0
    [digital2] => 1
    [estagio] => 2
    [periodo] => 5000
    [text] => 
)

*/

/*********************
Problemas a resolver:
	para que la lista sea dinámica no deben verse todos los elementos pero deben refrescarse poco a poco.
	alternativa 1: crear una página que devuelva el contenido en, p. ej. JSON, desde la página HTML se incluye un script que lea el JSON y cree el contenido.
	alternativa 2: crear una página que devuelva el contenido en HTML y se autoactualize.  Desde la página principal insertar el contenido con un iframe.
 *********************/
?>