<?php
return "\t<h2><a href=\"/notas/\">Últimos artículos</a></h2>\n".
	list_articles(0,0,"","<a href=\"/notas/page/1.html\">Artículos anteriores</a>",true,3);
?>